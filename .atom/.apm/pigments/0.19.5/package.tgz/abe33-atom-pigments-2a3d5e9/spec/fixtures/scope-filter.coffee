# comment = #ffffff

string = '#ffffff'
